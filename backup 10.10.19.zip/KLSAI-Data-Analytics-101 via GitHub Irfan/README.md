# KLSAI-Data-Analytics-101
Notes and Codes from Kuala Lumpur School of AI Class held on 12th of January 2019 (Evening Session)
### Dataset used for this class can be obtained from :
####        - http://www.data.gov.my/data/ms_MY/dataset/major-export-destination
####       -  http://www.data.gov.my/data/ms_MY/dataset/major-import-sources
